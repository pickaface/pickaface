<?php
defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
defined('P_ROOT') ? null : define('P_ROOT', dirname($_SERVER['PHP_SELF'], 3));

require_once 'functionsandglobals.php';

?>
