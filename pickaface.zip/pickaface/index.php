<?php
  defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
  header("Location: public" . DS . "frontend" . DS . "home.php");


  //added a new line
?>
