<?php
  defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
  header("Location: .." . DS . "index.php");
?>
