<footer>
  <div class="footer-container">
    <div class="footer-div">
      <dl class="downloads-list">
        <dt>downloads</dt>
        <dd><a href=<?php echo "..".DS."assets".DS."vitaldocuments".DS."machomathpostcard.pdf"?> download>MachoMath Faculty Resume</a></dd>
        <dd><a href=<?php echo "..".DS."assets".DS."vitaldocuments".DS."machomathflyer.pdf"?> download>MachoMath Flyer</a></dd>
        <dd><a href=<?php echo "..".DS."assets".DS."vitaldocuments".DS."machomathpostcard.pdf"?> download>MachoMath Postcard</a></dd>
        <dd><a href=<?php echo "..".DS."assets".DS."vitaldocuments".DS."onlineclassesterms.pdf"?> download>Online Classes Terms&Conditions</a></dd>
      </dl>
    </div>
    <div class="footer-div">
      <dl class="share-list">
        <dt>Social</dt>
        <div class="social-div">
          <div class="share-buttons">
            <dd>Share MachoMath on your page...</dd>
            <!-- Email -->
            <a title="Mail to a friend about MachoMath" href="mailto:?Subject=Let me tell you about MachoMath">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."email.png"?> alt="Email"></a>

            <!-- Facebook -->
            <a title="Share MachoMath on your FB page" href="http://www.facebook.com/sharer.php?u=https://machomath.com" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."facebook.png"?> alt="Facebook"></a>

            <!-- Google+ -->
            <a title="Share MachoMath on your Google+ page" href="https://plus.google.com/share?url=https://machomath.com" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."google.png"?> alt="Google"></a>

            <!-- LinkedIn -->
            <a title="Share MachoMath on your LinkedIn page" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://machomath.com" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."linkedin.png"?> alt="LinkedIn"></a>

            <!-- Twitter -->
            <a title="Share MachoMath on twitter" href="https://twitter.com/share?url=https://machomath.com&amp;text=For%20those%20who%20want%20to%20know%20Math&amp;hashtags=machomath" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."twitter.png"?> alt="Twitter"></a>


          </div>
          <div class="share-buttons">
            <dd>Visit MachoMath and like...</dd>
            <!-- Email -->
            <a title="Tell MachoMath how can we serve you better" href="mailto:info@machomath.com?Subject=Tell us how do you feel about MachoMath">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."email.png"?> alt="Email"></a>
            <!-- Facebook -->
            <a title="Visit our FB page and like" href="https://www.facebook.com/MachoMath-804951839844860/" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."facebook.png"?> alt="Facebook"></a>

            <!-- Google+ -->
            <a title="Visit our Google+ page" href="https://plus.google.com/share?url=https://machomath.com" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."google.png"?> alt="Google"></a>

            <!-- LinkedIn -->
            <a title="Visit our LinkedIn page" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://machomath.com" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."linkedin.png"?> alt="LinkedIn"></a>

            <!-- Twitter -->
            <a title="Follow MachoMath Twitter" href="https://twitter.com/share?url=https://machomath.com&amp;text=For%20those%20who%20want%20to%20know%20Math&amp;hashtags=machomath" target="_blank">
                <img src=<?php echo "..".DS."assets".DS."socialicons".DS."twitter.png"?> alt="Twitter"></a>
          </div>
        </div>
      </dl>

    </div>
    <div class="footer-div" dir="rtl">
      <dl class="views-list">
        <dt>Views</dt>
        <dd><a href=" https://calallenwildcatter.org/3783/news/prep-course-offered-friday-to-prepare-for-sat-test/" target="_blank">CHS Students Talking about MachoMath</a></dd>
      </dl>
    </div>
  </div>

  <div class="header-links-in-footer">
    <hr>
    <?php echo $html ?>
  </div>
  <div class="copy-right">
    <?php echo "&copy; MachoMath" . date("Y", time()); ?>
  </div>

</footer>
      <?php
        if(isset($alert_message)){
          echo "<script>alert('" . $alert_message . "')</script>";
        }
      ?>
      <script type="text/javascript" src=<?php echo "..".DS."javascript".DS."navbar.js";?>></script>
    </div>
  </body>
</html>
