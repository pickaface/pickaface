<?php
defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
require_once '..' .DS. 'layouts' .DS. 'head.php';
?>

      </header>
      <header>
        <h1>This is body</h1>
        <p>Yes this is the one</p>
      </header>
<?php require_once '..' .DS. 'layouts' .DS. 'foot.php'; ?>
